<?php
    $question=$_POST['question'];
    $option1=$_POST['option1'];
    $option2=$_POST['option2'];
    $option3=$_POST['option3'];
    $option4=$_POST['option4'];
    $correct=$_POST['correct'];
    $no=$_POST['no'];
    $name=$_POST['name'];
    $ma=$_POST['ma'];
    $rno=$_POST['rno'];
    $answer=$_POST['answer'];
    $questiontable=$questiontable=$_POST['questiontable'];
    $studenttable=$studenttable=$_POST['studenttable'];
    if($answer==$correct)
    {
        $ma=intval($ma)+1;
    }
    $con=mysqli_connect("localhost","root","");
    if($con!=null)
    {
        $db=mysqli_select_db($con,"beracah");
        if($db!=null)
        {
            $rs=mysqli_query($con,"select * from $questiontable;");
            $f=mysqli_num_rows($rs);
        }
    }
    if($no==$f)
    {
    ?>
        <form action="finish.php" method="post">
            <input type="hidden" value="<?php  echo $question; ?>" name="question" >
            <input type="hidden" value="<?php echo $option1; ?>" name="option1" >
            <input type="hidden" value="<?php echo $option2; ?>" name="option2" >
            <input type="hidden" value="<?php echo $option3; ?>" name="option3" >
            <input type="hidden" value="<?php echo $option4; ?>" name="option4" >
            <input type="hidden" value="<?php echo $correct; ?>" name="correct" >
            <input type="hidden" value="<?php echo $no; ?>" name="no">
            <input type="hidden" value="<?php echo $ma; ?>" name="ma">
            <input type="hidden" value="<?php echo $name; ?>" name="name">
            <input type="hidden" value="<?php echo $rno; ?>" name="rno">
            <input type="hidden" value="<?php echo $studenttable; ?>" name="studenttable">
            <input type="hidden" value="<?php echo $questiontable; ?>" name="questiontable">
            <input type="submit" value="SEE RESULTS">
        </form>
    <?php
    }
    else
    {
        $no=intval($no)+1;
        ?>
        <form action="exam.php" method="post">
            <input type="hidden" value="<?php  echo $question; ?>" name="question" >
            <input type="hidden" value="<?php echo $option1; ?>" name="option1" >
            <input type="hidden" value="<?php echo $option2; ?>" name="option2" >
            <input type="hidden" value="<?php echo $option3; ?>" name="option3" >
            <input type="hidden" value="<?php echo $option4; ?>" name="option4" >
            <input type="hidden" value="<?php echo $correct; ?>" name="correct" >
            <input type="hidden" value="<?php echo $no; ?>" name="no">
            <input type="hidden" value="<?php echo $ma; ?>" name="ma">
            <input type="hidden" value="<?php echo $name; ?>" name="name">
            <input type="hidden" value="<?php echo $rno; ?>" name="rno">
            <input type="hidden" value="<?php echo $studenttable; ?>" name="studenttable">
            <input type="hidden" value="<?php echo $questiontable; ?>" name="questiontable">
            <input type="submit" value="NEXT QUESTION">
        </form>
    <?php
    }
?>