<?php
    $name=$_POST['name'];
    $rno=$_POST['rno'];
    $class=$_POST['class'];
    $section=$_POST['section'];
    $student=$_POST['student'];
    $con=mysqli_connect("localhost","root","");
    $i=0;
    $j=0;
    $ma=0;
    $no=1;
    if($con!=null)
    {
        $db=mysqli_select_db($con,"beracah");
        if($db!=null)
        {
            $n=mysqli_query($con,"show tables;");
            while($check=mysqli_fetch_assoc($n))
            {
                foreach($check as $v)
                {
                    if($v==$class.$section)
                    {
                        $i=$i+1;
                    }
                }
            }
            $n=mysqli_query($con,"show tables;");
            while($check=mysqli_fetch_assoc($n))
            {
                foreach($check as $v)
                {
                    if($v=="student".$class.$section)
                    {
                        $j=$j+1;
                    }
                }
            }
            if($i==0 || $j==0)
            {
                echo "YOU OPENED UNAVAILABLE PORTAL FOR YOUR EXAM";
            }
            if($i!=0 && $j!=0)
            {   
                    ?>
                    <h2>CLICK BELOW TO GO TO EXAM PORTAL</h2><br>
                    <form action="exam.php" method="post">
                            <input type="hidden" value="<?php echo $name ?>" name="name">
                            <input type="hidden" value=" <?php echo $rno ?>" name="rno">
                            <input type="text" value=" <?php echo $class.$section ?>" name="questiontable" readonly>
                            <input type="hidden" value="<?php echo $student.$class.$section ?>" name="studenttable">
                        <input type="hidden" value="<?php echo "" ?>" name="question">
                        <input type="hidden" value="<?php echo "" ?>" name="correct">
                        <input type="hidden" value="<?php echo "" ?>" name="option1">
                        <input type="hidden" value="<?php echo "" ?>" name="option2">
                        <input type="hidden" value="<?php echo "" ?>" name="option3">
                        <input type="hidden" value="<?php echo "" ?>" name="option4">
                            <input type="hidden" value="<?php echo $no ?> " name="no">
                            <input type="hidden" value="<?php echo $ma ?> " name="ma">
                            <input type="submit" value="SUBMIT">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <input type="reset" value="RESET">
                    </form>
                    <?php
            }
            else
            {
                echo "<h2>ERROR IN CREATING <a nhref=student.html>CLICK TO TRY AGAIN</a></h2>";
            }
        }
        else
        {
            echo "DATABASE NOT FOUND";
        }
    }
    else
    {
        echo "CONNECTION ERROR";
    }
?>