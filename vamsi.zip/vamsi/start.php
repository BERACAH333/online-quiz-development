<?php
    $question=$_POST['question'];
    $option1=$_POST['option1'];
    $option2=$_POST['option2'];
    $option3=$_POST['option3'];
    $option4=$_POST['option4'];
    $correct=$_POST['correct'];
    $no=$_POST['no'];
    $name=$_POST['name'];
    $ma=$_POST['ma'];
    $rno=$_POST['rno'];
    $questiontable=$questiontable=$_POST['questiontable'];
    $studenttable=$studenttable=$_POST['studenttable'];
?>
        <form action="caluclate.php" method="post">
            QUESTION <?php echo $no; ?>:<input type="text" value="<?php echo $question; ?>" readonly size="120"><br>
            <input type="radio" name="answer" value="<?php echo $option1; ?>" size="50" readonly required="required"><?php echo $option1; ?><br><br>
            <input type="radio" name="answer" value="<?php echo $option2; ?>" size="50" readonly required="required" >
            <?php echo $option2; ?><br><br>
            <input type="radio" name="answer" value="<?php echo $option3; ?>" size="50" readonly required="required" ><?php echo $option3; ?><br><br>
            <input type="radio" name="answer" value="<?php echo $option4; ?>" size="50" readonly required="required"><?php echo $option4; ?><br><br>
            <input type="hidden" value="<?php  echo $question; ?>" name="question" >
            <input type="hidden" value="<?php echo $option1; ?>" name="option1" >
            <input type="hidden" value="<?php echo $option2; ?>" name="option2" >
            <input type="hidden" value="<?php echo $option3; ?>" name="option3" >
            <input type="hidden" value="<?php echo $option4; ?>" name="option4" >
            <input type="hidden" value="<?php echo $correct; ?>" name="correct" >
            <input type="hidden" value="<?php echo $no; ?>" name="no">
            <input type="hidden" value="<?php echo $ma; ?>" name="ma">
            <input type="hidden" value="<?php echo $name; ?>" name="name">
            <input type="hidden" value="<?php echo $rno; ?>" name="rno">
            <input type="hidden" value="<?php echo $studenttable; ?>" name="studenttable">
            <input type="hidden" value="<?php echo $questiontable; ?>" name="questiontable">
            <input type="submit" value="SUBMIT">
        </form>
    