<?php
    $question=$_POST['question'];
    $option1=$_POST['option1'];
    $option2=$_POST['option2'];
    $option3=$_POST['option3'];
    $option4=$_POST['option4'];
    $correct=$_POST['correct'];
    $no=$_POST['no'];
    $name=$_POST['name'];
    $ma=$_POST['ma'];
    $rno=$_POST['rno'];
    $questiontable=$questiontable=$_POST['questiontable'];
    $studenttable=$studenttable=$_POST['studenttable'];
    $con=mysqli_connect("localhost","root","");
    if($con!=null)
    {
        $db=mysqli_select_db($con,"beracah");
        if($db!=null)
        {
            $rs=mysqli_query($con,"insert into $studenttable values('".$name."','".$rno."',".$ma.");");
        }
    }
    ?>
    <form action="student.html" method="post">
        <h2>YOUR FINAL RESULTS ARE:</h2><br>
            <h3>NAME :</h3><?php echo $name ?><br>
            <h3>ROLL NUMBER :</h3><?php echo $rno ?><br>
            <h3>MARKS :</h3><?php echo $ma ?><br>
        <input type="submit" value="EXIT EXAM">
    </form>