<?php
    $no_of_questions=$_POST['no_of_questions'];
    $table=$_POST['table'];
    $con=mysqli_connect("localhost","root","");
    if($con!=null)
    {
        $db=mysqli_select_db($con,"beracah");
        if($db!=null)
        {
            $i=mysqli_query($con,"select * from ".$table.";");
            $n=mysqli_num_rows($i); 
        }
    }
?>
<form action="question.php" method="POST">
    <input type="hidden" value="<?php echo $no_of_questions ?>" name="no_of_questions" >
    <input type="hidden" value="<?php echo $table ?>"  name="table">
    <input type="hidden" value="<?php echo $n ?>"  name="n">
     ENTER  QUESTION&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<input type="text" name="question" size="100" required><br> <br> 
     ENTER OPTION1&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<input type="text" name="option1" size="30" required><br> <br> 
     ENTER OPTION2&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<input type="text" name="option2"  size="30" required><br> <br> 
     ENTER OPTION3&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<input type="text" name="option3" size="30" required><br> <br> 
     ENTER OPTION4&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<input type="text" name="option4" size="30"  required><br> <br> 
     ENTER CORRECT OPTION:<input type="text" name="correctoption" size="30" required><br> <br> 
     <input type="submit" value="SAVE AND NEXT">
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     <input type="reset" value="RESET"><br>
    <input type="text" value="NUMBER OF QUESTIONS PREPARED ARE: <?php echo $n; ?> " size="50">
    <br>
    <a href="save.php">COMPLETED</a>
</form>