<?php

    $no_of_questions=$_POST['no_of_questions'];
    $table=$_POST['table'];
    $n=$_POST['n'];
    $s1=$_POST['question'];
    $s2=$_POST['option1'];
    $s3=$_POST['option2'];
    $s4=$_POST['option3'];
    $s5=$_POST['option4'];
    $s6=$_POST['correctoption'];
    $con=mysqli_connect("localhost","root","");
    if($con!=null)
    {
        $db=mysqli_select_db($con,"beracah");
        if($db!=null)
        {
            $i=mysqli_query($con,"select * from ".$table.";");
            $p=mysqli_num_rows($i); 
            echo $p;
            $j=mysqli_query($con,"insert into ".$table." values('".$s1."','".$s2."','".$s3."','".$s4."','".$s5."','".$s6."')");
            if($j==null)
            {
                echo "ERROR IN QUESTIONING <a href=teacher.html>TRY AGAIN</a>";
            }
            else
            {
                
                if(intval($no_of_questions)==intval($p)+1)
                {
                    echo "SUCCESSFULLY PREPARED ONLINE BITS.<a href=index.html style=text-decoration:none>CLICK HERE TO GO TO HOME PAGE.</a>";
                }
                else if($j!=null)
                {
                    ?>
                        <form action="insert.php" name="fr" method="post">
                            <input type="hidden" value="<?php echo $no_of_questions ?>" name="no_of_questions">
                            <input type="hidden" value="<?php echo $table ?>" name="table">
                            <input type="submit" value="submit">
                        </form>
                    <?php
                }
                else
                {
                    echo "ERROR IN INSERTING";
                    ?>
                        <form action="insert.php" name="fr" method="post">
                            <input type="hidden" value="<?php echo $no_of_questions ?>" >
                            <input type="hidden" value="<?php echo $table ?>" >
                        </form>
                        <script type="text/javascript">
                            header("Refresh:5;");
                            document.fr.subimt();    
                        </script>
                    <?php
                }
            }
        }
        else
        {
            echo "ERROR IN DATABASE CONNECTION";
        }
    }
    else
    {
      echo "<a href=insert.php style=\'text-decoration:none\'>ERROR WHILE CONNECTING TO DATABASE.TRY AGAIN...</a?";   
    }
?>