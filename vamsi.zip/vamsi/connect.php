<?php
    $no_of_questions=$_POST['no_of_questions'];
    $class=$_POST['class'];
    $section=$_POST['section'];
    $con=mysqli_connect("localhost","root","");
    if($con!=null)
    {
        $db=mysqli_select_db($con,"beracah");
        if($db!=null)
        {
            $n=mysqli_query($con,"create table ".$class.$section." (question varchar(120),option1 varchar(30),option2 varchar(30),option3 varchar(30),option4 varchar(30),correct varchar(30))");
            $a=mysqli_query($con,"create table student".$class.$section." (name varchar(50),rno varchar(20),marks int);");
                
            ?>
            <form action="insert.php" method="post">
                <input type="hidden" name="no_of_questions" value="<?php echo $no_of_questions; ?>" readonly> 
                <input type="hidden" name="table" value="<?php echo $class.$section ?> "> 
                <h2>
                    YOU CHOOSE <input type="text" value="<?php if(intval($no_of_questions)<=9){echo "0".$no_of_questions;}else{echo $no_of_questions;} ?>" style="width:35px;font-size:22px;font-weight:bold" readonly> QUESTIONS.CLICK BELOW TO CONTINUE.
                </h2>
                <input type="submit" value="SUBMIT">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="reset" value="RESET">
            </form>
            <?php
        }
        else
        {
             echo "DATABASE IS NOT SELECTED ";
        }
    }
    else
    {
        echo"NOT CONNECTED";
    }
?>